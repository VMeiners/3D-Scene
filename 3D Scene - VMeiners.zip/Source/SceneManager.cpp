///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/*********************************************************** 
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 * 
 *  Settings for plasticMaterial, glassMaterial, & woodMaterial 
 *  implemented from the Module 6 assignment as the material 
 *  settings behaved as expected in order to replicate the 2D 
 *  photo in the 3D environment 
 * 
 *  Settings for foamMaterial and rugMaterial were implemented
 *  from scratch with the reasoning being that foam
 *  should behave similarly to plastic, but with less 
 *  shininess and rug would behave similarly to wood, also
 *  with less shininess 
 ***********************************************************/
void SceneManager::DefineObjectMaterials() {

	OBJECT_MATERIAL plasticMaterial;

	plasticMaterial.diffuseColor = glm::vec3(0.8f, 0.4f, 0.8f); 
	plasticMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f); 
	plasticMaterial.shininess = 0.4; 
	plasticMaterial.tag = "plastic"; 
	m_objectMaterials.push_back(plasticMaterial); 

	/********************************************************
	* FOAM MATERIAL 
	* 
	* the lego consists of a foam-like material wherein
	* plastic as a material would not allow the texture
	* of the lego to behave as expected
	* logically, the block is similar to plastic, but with
	* less reflective properties
	* the foam-material was created from the plastic material
	* with less shininess in order to replicate the behavior
	* of foam under light
	********************************************************/
	OBJECT_MATERIAL foamMaterial; 

	foamMaterial.diffuseColor = glm::vec3(0.8f, 0.4f, 0.8f); 
	foamMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f); 
	foamMaterial.shininess = 0.1; 
	foamMaterial.tag = "foam"; 
	m_objectMaterials.push_back(foamMaterial); 

	OBJECT_MATERIAL glassMaterial; 

	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f); 
	glassMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f); 
	glassMaterial.shininess = 0.3;
	glassMaterial.tag = "glass"; 
	m_objectMaterials.push_back(glassMaterial); 

	OBJECT_MATERIAL woodMaterial; 

	woodMaterial.diffuseColor = glm::vec3(0.6f, 0.5f, 0.2f); 
	woodMaterial.specularColor = glm::vec3(0.1f, 0.2f, 0.2f); 
	woodMaterial.shininess = 1.0;
	woodMaterial.tag = "wood"; 
	m_objectMaterials.push_back(woodMaterial); 

	/********************************************************
	* RUG MATERIAL
	*
	* the rug is a non-reflective material so a material
	* similar to wood was implemented, as the rug has 
	* brown-ish tones, as does wood, and has a low amount
	* of shininess, if any at all. 
	* 
	* the rug material was created from the wood material, 
	* but with some experimentation. 
	********************************************************/

	OBJECT_MATERIAL rugMaterial; 

	rugMaterial.diffuseColor = glm::vec3(0.6f, 0.5f, 0.2f); 
	rugMaterial.specularColor = glm::vec3(0.1f, 0.2f, 0.2f); 
	rugMaterial.shininess = 0.1; 
	rugMaterial.tag = "rug"; 
	m_objectMaterials.push_back(rugMaterial); 
}

/*********************************************************** 
*  LoadSceneTextures()
*
*  This method is used for preparing the 3D scene by loading
*  the shapes, textures in memory to support the 3D scene
*  rendering
* 
*  The 3D scene being rendered consists mostly of plastic
*  textures. 
*
*  For the bee block textures, 4 textures were created
*  in Photoshop to replicate the textures present on the
*  bee. 
*
*  Bee.jpg consists of entirely of yellow and was
*  created by taking a close up photo of the bee block in
*  good lighting and using the color picker to select a
*  close match in color. 
*  
*  Smile.jpg consists of the same yellow used in Bee.jpg
*  but it also includes the eyes and smile for the bee
*  block. Admittedly, the eyes need work in terms of 
*  positioning and stretch, but they are close a close
*  representation of the bee block smile which is a good
*  starting point. 
*  
*  Stripes.jpg consists of the same yellow, but also includes
*  3 black stripes, again color picked to match the black
*  of the bee block. Stripes was the base for Wings.jpg 
*  initially as an attempt was made to create a png of 
*  bee wings to overlay on top of Stripes.jpg, but this 
*  attempt was not successful. 
* 
*  Wings.jpg is consists of a yellow base, same as in
*  Bee.jpg, and 3 black stripes. It also contains the
*  bee wings in color matched blue with black stripes. 
* 
*  The textures were added to the 7-1 Final Project 
*  textures folder for access and loading within the Final
*  Project and are loaded successfully below. 
* 
*  Additional textures were created in Photoshop for the 
*  table, starburst toy, lego, and etch a sketch. 
*  Additional textures consist of plastic, wood, carpet, 
*  rubber, and a metallic texture. 
* 
*  All textures were changed in Hue/Saturation after being
*  downloaded from https://ambientcg.com/, a website with
*  creative commons textures, so that they matched the 
*  appropriate color of each object within the 2D scene.
*  The sketchTop, specifically, was created by utilizing
*  the same red as sketch but adding the Etch A Sketch
*  logo
* 
*  All textures were added to the textures folder and
*  loaded accordingly. 
***********************************************************/

void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	/*******************************************/
	/*           TABLE TEXTURES                */
	/*******************************************/

	// load tabletop texture - green plastic 
	bReturn = CreateGLTexture("textures/tabletop.jpg", "tabletop"); 

	// load tablebottom texture  - white plastice 
	bReturn = CreateGLTexture("textures/tablebottom.jpg", "tablebottom"); 

	/*******************************************/
	/*           STARBURST TEXTURE             */
	/*******************************************/

	// load starburst texture - pink plastic 
	bReturn = CreateGLTexture("textures/starburst.jpg", "starburst"); 

	/*******************************************/
	/*               LEGO TEXTURE              */
	/*******************************************/

	// load lego texture - rubber 
	bReturn = CreateGLTexture("textures/lego.jpg", "lego"); 

	/*******************************************/
	/*           BEE BLOCK TEXTURES            */
	/*******************************************/

	// load bee texture - yellow 
	bReturn = CreateGLTexture("textures/Bee.jpg", "bee"); 

	// load smile texture - yellow with smile
	bReturn = CreateGLTexture("textures/Smile.jpg", "smile");

	// load stripe texture - yellow wih stripes 
	bReturn = CreateGLTexture("textures/Stripes.jpg", "stripes"); 

	// load wing texture - yellow with stripes & wings 
	bReturn = CreateGLTexture("textures/Wings.jpg", "wings"); 

	/*******************************************/
	/*           ETCH A SKETCH TEXTURES        */
	/*******************************************/

	// load etch a sketch - red plastic 
	bReturn = CreateGLTexture("textures/sketch.jpg", "sketch");

	// load etch a sketch - red plastic with lettering
	bReturn = CreateGLTexture("textures/sketchTop.jpg", "sketchTop");

	// load etch a sketch - black plastic 
	bReturn = CreateGLTexture("textures/etchbottom.jpg", "etch"); 

	// load etch a sketch screen - silver metallic 
	bReturn = CreateGLTexture("textures/screen.jpg", "screen"); 

	/*******************************************/
	/*              WALL TEXTURES              */
	/*******************************************/

	// load wall texture - white wood paneling 
	bReturn = CreateGLTexture("textures/wall.jpg", "wall");

	/*******************************************/
	/*           CARPET TEXTURES               */
	/*******************************************/

	// load floor texture - carpet 
	bReturn = CreateGLTexture("textures/carpet.jpg", "carpet");

	BindGLTextures();

}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/*********************************************************** 
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 * 
 *  All lighting has been completely redone from the Module
 *  Six assignment in order to introduce more shadowing and
 *  depth to the scene 
 ***********************************************************/
void SceneManager::SetUpSceneLights() {

	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/***********************************************************
	*  Directional Light implemented to simulate light 
	*  originating from doorway, it is an overall ambient light
	*  used to create "natural" lighting within the 3D scene 
	***********************************************************/

	m_pShaderManager->setVec3Value("directionalLight.ambientColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setVec3Value("directionalLight.direction", -1.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	/***********************************************************
	*	Point Lights are implemented to simulate the overhead
	*   hallway light
	* 
	*   One point light was implemented in order to appropriately 
	*   light the center of the starburst, to minimize shadows. 
	*   This light is titled point light 0 - starburst. 
	*   point light 0 also has the specular settings increased in 
	*   order to add more shininess to the plastic material of 
	*   the starburst toy with reflective lighting.
	* 
	*   point light 1 and point light 2 were implemented to light
	*   the back of the scene, specficially the starburst toy
	*   and the etch a sketch. 
	* 
	*   point light 3 and point light 4 were implemented to light
	*   the front of the scene, specifically the lego block and
	*   the bee block. 
	*   point light 3 and point light 4 have their diffuse
	*   settings lowered in order to create some shadows on the
	*   front of the scene to make it more dynamic. 
	***********************************************************/ 

	// point light 0 - starburst 
	m_pShaderManager->setVec3Value("pointLights[0].position", -5.0f, 12.0f, 0.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// point light 1 - back 
	m_pShaderManager->setVec3Value("pointLights[1].position", -20.0f, 12.0f, -15.0f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// point light 2 - back 
	m_pShaderManager->setVec3Value("pointLights[2].position", 20.0f, 12.0f, -15.0f);
	m_pShaderManager->setVec3Value("pointLights[2].ambient", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[2].diffuse", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("pointLights[2].specular", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setBoolValue("pointLights[2].bActive", true);

	// point light 3 - front 
	m_pShaderManager->setVec3Value("pointLights[3].position", -15.0f, 12.0f, 10.0f);
	m_pShaderManager->setVec3Value("pointLights[3].ambient", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[3].diffuse", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[3].specular", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setBoolValue("pointLights[3].bActive", true);

	// point light 4 - front 
	m_pShaderManager->setVec3Value("pointLights[4].position", 15.0f, 12.0f, 12.0f);
	m_pShaderManager->setVec3Value("pointLights[4].ambient", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[4].diffuse", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[4].specular", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setBoolValue("pointLights[4].bActive", true);

}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene() {

	// call scene lights for 3D scene
	SetUpSceneLights();

	// call define materials for 3D scene 
	DefineObjectMaterials();

	// call loading scene textures for 3D scene 
	LoadSceneTextures();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();

/**********************************************************
* Loading Shapes for Final Project - 
* The Plane Mesh was pre-loaded
* The shapes which the reference photo conists of call for
* Toruses, Cylinders, Spheres, and Boxes
* As such, the above shapes were loaded for use below
**********************************************************/

	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadBoxMesh();

}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	
	/******************************************************************
	* CHANGES TO PLANE SHAPE: 
	* 
	* scaleXYZ of the plane mesh was changed to
	* scalXYZ = glm::vec3(30.0f, 1.0f, 30.0f) 
	* The change was implemented to reflect the source photo more
	* accurately
	* The source photo consists of a green table, acting as a plane,
	* wherein the objects for Project One are staged
	* The plane was changed from a rectangular shape to a square shape
	* by manipulating the scale on the X Axis and Z Axis while leaving
	* the Y Axis in tact to maintain the thinness of the plane
	*******************************************************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(30.0f, 1.0f, 30.0f); 

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/*******************************************************************
	* CHANGES TO PLANE SHAPE: 
	* 
	* The original SetShaderColor was SetShaderColor(1, 1, 1, 1)
	* As such, the plane was white
	* The source photo's plane, in this case a square table, is green
	* The plane was initially set to a green, but later textures 
	* and materials were implemented wherein the table top now 
	* consists of a green plastic texture. 
	*******************************************************************/

	// set textures
	SetShaderTexture("tabletop");
	SetTextureUVScale(4.0, 4.0);

	// set shader material
	SetShaderMaterial("plastic"); 

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

/****************************************************************/

/*********************************************************************
* IMPLEMENTATION OF ADDITIONAL BOX SHAPE 
* 
* The additional box shape was implemented to add depth to the scene
* In the source photo, the plane is green, but the plane is not
* wholly a plane
* The source photo shows a small table with a green surface and 
* a white border
* An additonal box shape was created to implement the white border
* 
* The additional box shape has a X,Y,Z rotation of 0.0f as it has
* to match the rotation of the plane in order to be part of the plane
* 
* The additional box shape is set scaleXYZ = glm::vec3(61.0f, 4.0f, 61.0f);
* to give it a similar depth to the table
* 
* The additional box shape is at positionXYZ = glm::vec3(0.0f, -2.1f, 0.0f); 
* This is so the box sits directly underneath the plane
* 
* As the table edge is white in the source photo, SetShaderColor was
* set to SetShaderColor(1, 1, 1, 1);
* However, textures and materials were later added so the table now
* consists of a white plastic texture. 
*********************************************************************/

	// scale of additional box shape 
	scaleXYZ = glm::vec3(61.0f, 4.0f, 61.0f);

	// rotation of additional box shape
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of additional box shape
	positionXYZ = glm::vec3(0.0f, -2.1f, 0.0f); 

	// transformations of additional box shape
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("tablebottom");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic"); 

	// draw additional box shape
	m_basicMeshes->DrawBoxMesh();

/***********************************************************
*  Implementation of Cylinders for Table Legs
*  
*  Cylinders were added to produce legs for the table, as
*  was represented in the 2D photo. 
*  
*  Cylinders 1 through 4 are the legs. 
* 
*  Short Cylinders 1 through 4 are the caps at the end of
*  each table leg. 
* 
*  As the cylinders are part of the table, they consist of
*  a white, plastic texture to match the table bottom. 
***********************************************************/

	/*******************************************/
	/*           CYLINDER SHAPE 1              */
	/*******************************************/

	// scale of cylinder shape 1 for leg
	scaleXYZ = glm::vec3(1.5f, 29.0f, 1.5f);

	// rotation of cylinder shape 1 for leg
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position of cylinder shape 1 for leg
	positionXYZ = glm::vec3(-29.0f, -30.0f, 29.0f);

	// transformations of cylinder shape 1 for leg
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("tablebottom");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw additional box shape
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*           CYLINDER SHAPE 2              */
	/*******************************************/

	// scale of cylinder shape 2 for leg
	scaleXYZ = glm::vec3(1.5f, 29.0f, 1.5f);

	// rotation of cylinder shape 2 for leg
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position of cylinder shape 2 for leg
	positionXYZ = glm::vec3(29.0f, -30.0f, 29.0f);

	// transformations of cylinder shape 2 for leg
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("tablebottom");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw additional box shape
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*           CYLINDER SHAPE 3              */
	/*******************************************/

	// scale of cylinder shape 3 for leg
	scaleXYZ = glm::vec3(1.5f, 29.0f, 1.5f);

	// rotation of cylinder shape 3 for leg
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position of cylinder shape 3 for leg
	positionXYZ = glm::vec3(-29.0f, -30.0f, -29.0f);

	// transformations of cylinder shape 3 for leg
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("tablebottom");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw additional box shape
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*           CYLINDER SHAPE 4              */
	/*******************************************/

	// scale of cylinder shape 4 for leg
	scaleXYZ = glm::vec3(1.5f, 29.0f, 1.5f);

	// rotation of cylinder shape 4 for leg
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position of cylinder shape 4 for leg
	positionXYZ = glm::vec3(29.0f, -30.0f, -29.0f);

	// transformations of cylinder shape 4 for leg
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("tablebottom");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw additional box shape
	m_basicMeshes->DrawCylinderMesh();

/***********************************************************
*  Implementation of Short Cylinders for Table Legs
*
*  Four shorter cylinders were created to replicate the 
*  caps at the end of each table leg. 
* 
*  The shorter cylinders were created in the same space as 
*  the original cylinders for the table legs, only shorter. 
* 
*  Similar to the longer cylinders, the short cylinders
*  also consist of a white, plastic texture to match the
*  table bottom and longer cylinders. 
***********************************************************/

/*******************************************/
/*           CYLINDER SHAPE 1              */
/*******************************************/

	// scale of cylinder shape 1 for leg
	scaleXYZ = glm::vec3(1.7f, 1.5f, 1.7f);

	// rotation of cylinder shape 1 for leg
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position of cylinder shape 1 for leg
	positionXYZ = glm::vec3(-29.0f, -30.0f, 29.0f);

	// transformations of cylinder shape 1 for leg
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("tablebottom");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw additional box shape
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*           CYLINDER SHAPE 2              */
	/*******************************************/

	// scale of cylinder shape 2 for leg
	scaleXYZ = glm::vec3(1.7f, 1.5f, 1.7f);

	// rotation of cylinder shape 2 for leg
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position of cylinder shape 2 for leg
	positionXYZ = glm::vec3(29.0f, -30.0f, 29.0f);

	// transformations of cylinder shape 2 for leg
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("tablebottom");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw additional box shape
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*           CYLINDER SHAPE 3              */
	/*******************************************/

	// scale of cylinder shape 3 for leg
	scaleXYZ = glm::vec3(1.7f, 1.5f, 1.7f);

	// rotation of cylinder shape 3 for leg
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position of cylinder shape 3 for leg
	positionXYZ = glm::vec3(-29.0f, -30.0f, -29.0f);

	// transformations of cylinder shape 3 for leg
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("tablebottom");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw additional box shape
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*           CYLINDER SHAPE 4              */
	/*******************************************/

	// scale of cylinder shape 4 for leg
	scaleXYZ = glm::vec3(1.7f, 1.5f, 1.7f);

	// rotation of cylinder shape 4 for leg
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position of cylinder shape 4 for leg
	positionXYZ = glm::vec3(29.0f, -30.0f, -29.0f);

	// transformations of cylinder shape 4 for leg
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("tablebottom");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw additional box shape
	m_basicMeshes->DrawCylinderMesh();

/***********************************************************  
*  Implementation of Additional Planes as Wall
*
*  A plane was implemented and rotated into place so that
*  it is the wall behind the small table, as represented 
*  in the 2D photo. 
* 
*  The wall plane is textured with the wall texture, a
*  texture that was created from a wood plank texture
*  by rotating the planks and changing the color from 
*  brown to white in Photoshop. 
* 
*  Three walls have been implemented so that the texture 
*  more accurately represents the photo 
***********************************************************/

	/*******************************************/
	/*                 WALL 1                  */
	/*******************************************/
	
	// scale of wall 1
	scaleXYZ = glm::vec3(60.0f, 1.0f, 25.0f);

	// rotation of wall 
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// position for wall 
	positionXYZ = glm::vec3(0.0f, 30.0f, -32.0f);

	// transformations for wall 
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("wall");
	SetTextureUVScale(4.0, 4.0);

	// set shader material
	SetShaderMaterial("wood");

	m_basicMeshes->DrawPlaneMesh();

	/*******************************************/
	/*                 WALL 2                  */
	/*******************************************/

	// scale of wall 2
	scaleXYZ = glm::vec3(60.0f, 1.0f, 25.0f);

	// rotation of wall 2
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// position for wall 2
	positionXYZ = glm::vec3(50.0f, 30.0f, -32.0f);

	// transformations for wall 2
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures for wall 2
	SetShaderTexture("wall");
	SetTextureUVScale(4.0, 4.0);

	// set shader material for wall 2
	SetShaderMaterial("wood");

	m_basicMeshes->DrawPlaneMesh();

	/*******************************************/
	/*                 WALL 3                  */
	/*******************************************/

	// scale of wall 3
	scaleXYZ = glm::vec3(60.0f, 1.0f, 25.0f);

	// rotation of wall 3
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// position for wall 3
	positionXYZ = glm::vec3(-50.0f, 30.0f, -32.0f);

	// transformations for wall 3
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures for wall 3
	SetShaderTexture("wall");
	SetTextureUVScale(4.0, 4.0);

	// set shader material for wall 3
	SetShaderMaterial("wood");

	m_basicMeshes->DrawPlaneMesh();

/***********************************************************
*  Implementation of Additional Plane as Floor 
*
*  A plane was implemented to represent the floor in the 
*  2D photo. 
* 
*  A carpet texture that was similar to the texture in the 
*  2D photo was utilized to replicate the photo. 
**********************************************************/

	// scale of carpet  
	scaleXYZ = glm::vec3(75.0f, 1.0f, 50.0f); // FIXME - width of floor

	// rotation of carpet
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position for carpet 
	positionXYZ = glm::vec3(0.0f, -30.0f, -10.0f);

	// transformations for carpet
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures for carpet 
	SetShaderTexture("carpet");
	SetTextureUVScale(1.0, 1.0);

	// set shader material for carpet 
	SetShaderMaterial("rug");

	m_basicMeshes->DrawPlaneMesh();

/****************************************************************
* Implementation of Meshes for Starburst Toy - 
* The pink starburst toy, as shown in the reference photo, 
* can be broken down into toruses, cylinders, and spheres
*
* Toruses will be implemented to provide the center piece
* of the starburst toy, conjoining with the cylinders at 
* an angle which protrude from the torus grouping
* 
* Each cylinder will be intersected with a sphere at the end
*
* A group of toruses are required to ensure the overall shape
* is similar in thickness to the starburst toy in the source
* photo
****************************************************************/

/****************************************************************
* Torus Shape Implementation  - Starburst Toy
*
* The source photo requires 1 torus shape in total for the center
* of the starburst toy
* Increasing the scale of the torus does not increase the thickness
* of the shape itself, but instead increases the size in terms of
* circumference only
* As such, 3 toruses have been grouped together in order to meet
* the requirements as illustrated in the source photo
* 
* Each torus has an XrotationDegrees = 90.0f as the torus needs to
* lie parallel with the plane
* The YrotationDegrees and ZrotationDegrees are irrelevant to the 
* torus grouping 
* 
* The position of the torus is to the left, in terms of viewing
* the project in the view space
* The position of the torus is off center, as the starburst toy
* in the reference photo is toward the back left quadrant of 
* the plane
* 
* The scale of each torus differs as the toruses sit within one 
* another to increase the thickness of the torus, creating what
* is being referred to as the 'torus grouping'
* The toruses need to remain grouped in order to replicate the 
* thickness of the torus in the source photo
* 
* As the toruses are grouped together, each torus differs in scale
* slightly
* Torus Shape 1 is the outer torus with a setting of 
* scaleXYZ = glm::vec3(2.5f, 2.5f, 2.5f); 
* Torus Shape 2 is an inner torus with a setting of 
* scaleXYZ = glm::vec3(2.1f, 2.1f, 2.1f);
* Torus Shape 3 is the innermost torus with a setting of
* scaleXYZ = glm::vec3(1.7f, 1.7f, 1.7f);
* 
* Each torus position must be related to the other so that the
* toruses remain grouped together
* Each torus is set to positionXYZ = glm::vec3(-8.0f, 1.5f, -3.0f);
* 
* The starburst toy in the source photo is pink
* Each torus was set to SetShaderColor(1.00, 0.412, 0.706, 1);
* to closely match the color of the toy in the source photo. 
* Since textures and materials have been introduced into the 
* 3D environment, the toruses are now set to a pink, plastic
* texture. 
****************************************************************/

	/*******************************************/
	/*           TORUS SHAPE 1                 */
	/*******************************************/

	// scale of torus shape 1
	scaleXYZ = glm::vec3(2.5f, 2.5f, 2.5f); 

	// rotation of torus shape 1
	XrotationDegrees = 90.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of torus shape 1
	positionXYZ = glm::vec3(-8.0f, 1.5f, -3.0f);

	// transformations of torus shape 1
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(2.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw torus shape 1
	m_basicMeshes->DrawTorusMesh();

	/*******************************************/
	/*           TORUS SHAPE 2                 */
	/*******************************************/

	// scale of torus shape 2
	scaleXYZ = glm::vec3(2.1f, 2.1f, 2.1f);

	// rotation of torus shape 2
	XrotationDegrees = 90.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of torus shape 2
	positionXYZ = glm::vec3(-8.0f, 1.5f, -3.0f);

	// transformations of torus shape 2
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(2.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw torus shape 2
	m_basicMeshes->DrawTorusMesh();

	/*******************************************/
	/*           TORUS SHAPE 3                 */
	/*******************************************/

	// scale of torus shape 3
	scaleXYZ = glm::vec3(1.7f, 1.7f, 1.7f); 

	// rotation of torus shape 3
	XrotationDegrees = 90.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of torus shape 3
	positionXYZ = glm::vec3(-8.0f, 1.5f, -3.0f);

	// transformations of torus shape 3
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(2.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw torus shape 3
	m_basicMeshes->DrawTorusMesh();

/****************************************************************
* Cylinder Shape Implementation  - Starburst Toy
* 
* The source photo requires 6 cylinders total for each spoke 
* protruding from the starburst toy 
*
* Each cylinder has a rotation of XrotationDegrees = 90.0f as 
* the cylinders must sit parallel to the plane 
* The ZrotationDegrees for the cylinders is irrelevant 
* The YrotationDegrees varies from cylinder to cylinder  
* The YrotationDegrees for each cylinder is dependent upon the  
* cylinder's position in relation to the torus grouping 
* YrotationDegrees of the cylinders range from 
* YrotationDegrees = 115.0f to YrotationDegrees = -5.0f
* 
* The position of each cylinder is dependent on the cylinder's
* placement in relation to the torus grouping
* The cylinders circle the torus grouping
* The cylinders have a cylinder opposite each cylinder on the
* torus grouping 
* The cylinder positions allow the cylinders to intersect with
* the torus grouping
* Additionally, all cylinders must be set to 1.0f on the Y Axis
* positionally as they sit parallel to the plane, but must
* never touch the plane
* Each cylinder is numbered 1 through 6, for best coding 
* practices in that the code is readable and knowable
* 
* The scale of each cylinder is set to the following
* scaleXYZ = glm::vec3(0.50f, 1.5f, 0.50f);
* The scale of each cylinder must be uniform as is required
* from the source photo
* 
* As is the same with the torus grouping, the cylinders were set 
* to SetShaderColor(1.00, 0.412, 0.706, 1); as this color
* closely matches the source photo. However, after introducing
* textures and material, each cylinder is now implemented with
* a pink, plastic texture. 
****************************************************************/

	/*******************************************/
	/*           CYLINDER SHAPE 1              */
	/*******************************************/

	// scale of cylinder shape 1
	scaleXYZ = glm::vec3(0.50f, 1.5f, 0.50f);

	// rotation of cylinder shape 1
	XrotationDegrees = 90.0f;
	YrotationDegrees = 110.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 1
	positionXYZ = glm::vec3(-5.35f, 1.5f, -4.0f);

	// transformations of cylinder shape 1
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(2.0, 3.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw cylinder shape 1
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/ 
	/*           CYLINDER SHAPE 2              */
	/*******************************************/

	// scale of cylinder shape 2
	scaleXYZ = glm::vec3(0.50f, 1.5f, 0.50f);

	// rotation of cylinder shape 2
	XrotationDegrees = 90.0f;
	YrotationDegrees = 110.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 2
	positionXYZ = glm::vec3(-12.0f, 1.5f, -1.8f);

	// transformations of cylinder shape 2
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(2.0, 3.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw cylinder shape 2
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*           CYLINDER SHAPE 3              */
	/*******************************************/

	// scale of cylinder shape 3
	scaleXYZ = glm::vec3(0.50f, 2.5f, 0.50f);

	// rotation of cylinder shape 3
	XrotationDegrees = 90.0f; 
	YrotationDegrees = -7.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 3
	positionXYZ = glm::vec3(-8.5f, 1.5f, -0.50f);

	// transformations of cylinder shape 3
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(2.0, 3.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw cylinder shape 3
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*           CYLINDER SHAPE 4              */
	/*******************************************/

	// scale of torus shape 4
	scaleXYZ = glm::vec3(0.50f, 2.5f, 0.50f);

	// rotation of torus shape 5
	XrotationDegrees = 90.0f; 
	YrotationDegrees = 45.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 4
	positionXYZ = glm::vec3(-6.0f, 1.5f, -1.5f);

	// transformations of cylinder shape 4
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(2.0, 3.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw cylinder shape 4
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*           CYLINDER SHAPE 5              */
	/*******************************************/

	// scale of cylinder shape 5
	scaleXYZ = glm::vec3(0.50f, 1.90f, 0.50f);

	// rotation of cylinder shape 5
	XrotationDegrees = 90.0f; 
	YrotationDegrees = 51.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 5
	positionXYZ = glm::vec3(-11.0f, 1.5f, -6.0f);

	// transformations of cylinder shape 5
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(2.0, 3.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw cylinder shape 5
	m_basicMeshes->DrawCylinderMesh(); 

	/*******************************************/
	/*           CYLINDER SHAPE 6              */
	/*******************************************/

	// scale of cylinder shape 6
	scaleXYZ = glm::vec3(0.50f, 1.5f, 0.50f);

	// rotation of cylinder shape 6
	XrotationDegrees = 90.0f;
	YrotationDegrees = -10.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 6
	positionXYZ = glm::vec3(-7.0f, 1.5f, -7.0f);

	// tranformations of cylinder shape 6
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(2.0, 3.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw cylinder shape 6
	m_basicMeshes->DrawCylinderMesh();

/****************************************************************
* Sphere Shape Implementation  - Starburst Toy
* 
* The source photo requires 6 spheres
* The spheres must be connected to each cylinder that protrudes
* from the torus grouping
* 
* Each sphere has an XrotationDegrees, YrotationDegrees, and 
* ZrotationDegrees of 0.0f
* The rotations are set as such because the shape is a sphere
* and is uniform in shape and, in this case, scale so the spheres
* do not need to be rotated to meet the requirements set in the
* source photo
* 
* The position of each sphere is dependent on each assigned
* cylinder's placement in relation to the torus grouping
* 1 sphere must intersect with 1 cylinder exactly
* Additionally, for good coding practices, each sphere is labeled
* as Sphere Shape 1 through Sphere Shape 6
* Each Sphere Shape is linked to their respective cylinder
* For example, Sphere Shape 1 relates to Cylinder Shape 1, etc.
* However, the Y Axis position of each sphere is set to 1.5f
* This allows the sphere to touch the plane, but not go through
* the plane
* 
* Each sphere must be uniform in shape to match the source photo
* The scale of each sphere is set to 
* scaleXYZ = glm::vec3(1.75f, 1.75f, 1.75f); which is now smaller
* as feedback on Milestone was applied
*
* As with the torus grouping and cylinders, the sphere shapes were
* set to SetShaderColor(1.00, 0.412, 0.706, 1); in order to meet
* the required color scheme of the source photo. 
* Upon implementation of textures and material, the spheres have
* been set with a pink, plastic texture. 
****************************************************************/

	/*******************************************/  
	/*           SPHERE SHAPE 1                */
	/*******************************************/

	// scale of sphere shape 1 - for cylinder 1
	scaleXYZ = glm::vec3(1.75f, 1.75f, 1.75f);

	// rotation of sphere shape 1 - for cylinder 1
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of sphere shape 1 - for cylinder 1
	positionXYZ = glm::vec3(-2.5f, 2.0f, -5.0f); 

	// transformations of sphere shape 1 - for cylinder 1
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw sphere shape 1 - for cylinder 1
	m_basicMeshes->DrawSphereMesh();

	/*******************************************/
	/*           SPHERE SHAPE 2                */
	/*******************************************/

	// scale of sphere 2 - for cylinder 2
	scaleXYZ = glm::vec3(1.75f, 1.75f, 1.75f);

	// rotation of sphere shape 2 - for cylinder 2
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of sphere shape 2 - for cylinder 2
	positionXYZ = glm::vec3(-13.25f, 2.0f, -1.0f); 

	// transformations of sphere shape 2 - for cylinder 2
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw sphere shape 2 - for cylinder 2
	m_basicMeshes->DrawSphereMesh();

	/*******************************************/
	/*           SPHERE SHAPE 3               */
	/*******************************************/

	// scale of sphere shape 3 - for cylinder 3
	scaleXYZ = glm::vec3(1.75f, 1.75f, 1.75f);

	// rotation of sphere shape 3 - for cylinder 3
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of sphere 3 - for cylinder 3
	positionXYZ = glm::vec3(-9.0f, 2.0f, 2.5f); 

	// transformations of sphere shape 3 - for cylinder 3
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw sphere shape 3 - for cylinder 3
	m_basicMeshes->DrawSphereMesh();

	/*******************************************/
	/*           SPHERE SHAPE 4                */
	/*******************************************/

	// scale of sphere shape 4 - for cylinder 4
	scaleXYZ = glm::vec3(1.75f, 1.75f, 1.75f);

	// rotation of sphere shape 4 - for cylinder 4
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of sphere shape 4 - for cylinder 4
	positionXYZ = glm::vec3(-3.5f, 2.0f, 0.75f); 

	// transformations of sphere shape 4 - for cylinder 4
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw sphere shape 4 - for cylinder 4
	m_basicMeshes->DrawSphereMesh();

	/*******************************************/
	/*           SPHERE SHAPE 5                */
	/*******************************************/

	// scale for sphere shape 5 - for cylinder 5
	scaleXYZ = glm::vec3(1.75f, 1.75f, 1.75f);

	// rotation for sphere shape 5 - for cylinder 5
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position for sphere shape 5 - for cylinder 5
	positionXYZ = glm::vec3(-12.2f, 2.0f, -7.0f);

	// transformations of sphere shape 5 - for cylinder 5
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw sphere shape 5 - for cylinder 5
	m_basicMeshes->DrawSphereMesh();

	/*******************************************/
	/*           SPHERE SHAPE 6                */
	/*******************************************/

	// scale of sphere shape 6 - for cylinder 6
	scaleXYZ = glm::vec3(1.75f, 1.75f, 1.75f);

	// rotation of sphere shape 6 - for cylinder 6
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of sphere shape 6 - for cylinder 6
	positionXYZ = glm::vec3(-6.5f, 2.0f, -8.5f); 

	// transformation of sphere shape 6 - for cylinder 6
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	// set textures
	SetShaderTexture("starburst");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw sphere shape 6 - for cylinder 6
	m_basicMeshes->DrawSphereMesh();

/****************************************************************/

/****************************************************************
* Implementation of Meshes for Offbrand Lego Block -
* 
* The offbrand lego block, as illustrated in the source photo,
* consists of 1 block and 4 cylinders
* 
* A box will be implemented, in relation to the previous starburst
* toy. 
* 
* The box will intersect with 4 equally spaced cylinders
****************************************************************/

/****************************************************************
* Box Shape Implementation  - Offbrand Lego
* 
* The box is set to YrotationDegrees = -25.0f; 
* The YrotationDegrees is set as such so that the corner of the
* box is pointed toward the camera in the view space, as it is
* in the source photo
* The XrotationDegrees and ZrotationDegrees are irrelevant
* 
* The box is set to positionXYZ = glm::vec3(-5.0f, 1.75f, 14.0f);
* as this allows the box to sit 'in front of' the starburst toy, 
* per the source photo
* The box is located on the left, front quadrant of the plane
* 
* The scale of the box is scaleXYZ = glm::vec3(7.5f, 3.5f, 7.5f);    
* The box is slightly wider than it is tall 
* The box sits at nearly the same height as the tops of the 
* spheres in the starburst toy
*
* The offbrand lego block was set to match the color
* in the source photo SetShaderColor(0.847, 0.749, 0.847, 1); 
* With the implementation of textures and materials, the lego
* block is now set to a lavender, foam texture. 
****************************************************************/

	/*******************************************/
	/*           BOX SHAPE 1                   */
	/*******************************************/

	// scale of box shape 1
	scaleXYZ = glm::vec3(7.5f, 3.5f, 7.5f); 

	// rotation of box shape 1
	XrotationDegrees = 0.0f; 
	YrotationDegrees = -25.0f; 
	ZrotationDegrees = 0.0f; 

	// position of box shape 1
	positionXYZ = glm::vec3(-5.0f, 1.75f, 14.0f);

	// transformations of box shape 1
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	SetShaderTexture("lego");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("foam");

	// draw box shape 1
	m_basicMeshes->DrawBoxMesh();

/****************************************************************
* Cylinder Shape Implementation For Box Shape 1 - Offbrand Lego
* 
* The cylinders are set to X, Y, Z rotations of 0.0f as 
* the cylinders are uniform and do not need to be rotated
* 
* The cylinders are set at positions on the X and Z Axis
* in relation to their dependency on the box shape
* The cylinders are set at a position of 2.0f on the Y Axis
* so that the tops of the cylinders protrude from the box, as
* they do in the source photo
* 
* The scale of each cylinder is set to 
* scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f); so that the cylinders
* are uniform and placed equidistant from one another within the
* box shape/appearing on top of the box shape
* 
* The cylinders were set at SetShaderColor(0.847, 0.749, 0.847, 1);
* as is the box shape, per the source photo, and instead now 
* consist of a lavender, foam texture. 
****************************************************************/

	/*******************************************/
	/*   CYLINDER SHAPE 1  - FOR BOX SHAPE 1   */
	/*******************************************/

	// scale of cylinder shape 1 - for box shape 1
	scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f); 

	// rotation of cylinder shape 1 - for box shape 1
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	XrotationDegrees = 0.0f; 

	// position of cylinder shape 1 - for box shape 1
	positionXYZ = glm::vec3(-7.5f, 2.0f, 15.0f);

	// transformations of cylinder shape 1 - for box shape 1
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	SetShaderTexture("lego");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("foam");

	// draw cylinder shape 1 - for box shape 1
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*   CYLINDER SHAPE 2  - FOR BOX SHAPE 1   */
	/*******************************************/

	// scale of cylinder shape 2 - for box shape 1
	scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f);

	// rotation of cylinder shape 2 - for box shape 1
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 2 - for box shape 1
	positionXYZ = glm::vec3(-6.0f, 2.0f, 11.5f);

	// transformations of cylinder shape 2 - for box shape 1
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("lego");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("foam");

	// draw cylinder shape 2 - for box shape 1
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*   CYLINDER SHAPE 3  - FOR BOX SHAPE 1   */
	/*******************************************/

	// scale of cylinder shape 3 - for box shape 1
	scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f); 

	// rotation of cylinder shape 3 - for box shape 1
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 3 - for box shape 1
	positionXYZ = glm::vec3(-4.0f, 2.0f, 16.7f);

	// transformations of cylinder shape 3 - for box shape 1
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	SetShaderTexture("lego");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("foam");

	// draw cylinder shape 3 - for box shape 1
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*   CYLINDER SHAPE 4  - FOR BOX SHAPE 1   */
	/*******************************************/

	// scale of cylinder shape 4 - for box shape 1
	scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f); 

	// rotation of cylinder shape 4 - for box shape 1
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 4 - for box shape 1
	positionXYZ = glm::vec3(-2.5, 2.0f, 13.2f);

	// transformation of cylinder shape 4 - for box shape 1
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("lego");
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("foam");

	// draw cylinder shape 4 - for box shape 1
	m_basicMeshes->DrawCylinderMesh();

/****************************************************************
* Implementation of Meshes for Bee Block -
*
* The bee block, as illustrated in the source photo,
* consists of a cylinder, a sphere, and two toruses each positioned
* at the end of the cylinder to give it's rounded shape
*
* A cylinder will be implemented to the left of the off brand
* lego block, right side in camera view, and the sphere and
* toruses will be integrated with the central cylinder shape
* 
* An additional cylinder was added after experimentation with 
* adding textures yielded unwanted results in the form of the 
* stripe pattern being present on the top of the cylinder. Such
* stripes did not accurately reflect the 2D photo so the 
* additional cylinder was added as a workaround to this problem 
****************************************************************/

/****************************************************************
* Cylinder Shape Implementation  - Bee Block
* 
* Cylinder Shape 1 is the main shape
* Cylinder Shape 2 is the base shape
* Cylinder Shape 3 is the base for the sphere shape 1
* Cylinder Shape 4 is the top shape which allows for an accurate
* representation of the bee block in terms of textures 
*
* The rotation of all cylinders is set to 0.0f on the X, Y, and
* Z axis as the cylinders do not need to be rotated in a particular
* way in order to represent the 2D photo accurately
*
* All four cylinders have an X position of 7.0f and a Z position
* of 14.0f as they must sit directly on top of one another in 
* order to represent the 2D photo. Cylinder Shape 1's Y position 
* is 0.75f, Cylinder Shape 2's Y position is 0.0f, Cylinder Shape
* 3's Y position is 3.0f, and Cylinder Shape 4's Y position is 
* 3.0f. Cylinder Shape 1 is the main cylinder while Cylinder Shape
* 2 sits below Cylider 1 and Cylinder Shape 3 sits above Cylinder 1.
* However, Cylinder 3 is meant to be the base of sphere so it was
* necessary to include a fourth cylinder to act as the "top" of 
* Cylinder 1. Cylinder Shape 4 sits atop Cylinder Shape 1 so that
* Bee.jpg can be implemented as a texture to apply the appropriate
* color to the correct place on the bee block
*
* The cylinders all vary in scale. Cylinder Shape 1 is the largest
* as it is the base cylinder for the bee block at 2.5f, 2.75f, 2.5f)
* Cylinder Shape 2 is the second largest as it sits below the bee
* block as the smaller base at (2.0f, 2.5f, 2.0f). Cylinder Shape
* 3 is at a scale of (1.5f, 1.5f, 1.5f) as it sits atop Cylinder
* Shape 1, acting as the base for the Sphere Shape. Cylinder Shape
* 4's scale is (2.0f, 0.75f, 2.0f) as it acts as a lid to Cylinder
* Shape 1. 
* 
* All SetShaderColors were originally set to a yellow. However, now
* that textures are being implemented, custom textures were created
* to apply to every shape associated with the bee block in order to
* accurately represent the bee block from the 2D photo. 
****************************************************************/

	/*******************************************/
	/*          CYLINDER SHAPE 1               */
	/*******************************************/

	// scale of cylinder shape for bee block
	scaleXYZ = glm::vec3(2.5f, 2.75f, 2.5f); 

	// rotation of cylinder shape for bee block
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape for bee block
	positionXYZ = glm::vec3(7.0f, 0.75f, 14.0f);

	// transformations of cylinder shape for bee block
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	/**********************************************
	* SetShaderColor was removed as a texture 
	* has been implemented for the shape
	* 
	* As Cylinder 1 is the main base of the bee 
	* block, the custom texture Wings.jpg was
	* loaded and set in order to utilize it on
	* Cylinder Shape 1
	**********************************************/
	SetShaderTexture("wings"); 
	SetTextureUVScale(2.0, 2.0); 

	// draw cylinder shape for bee block
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*          CYLINDER SHAPE 2               */
	/*******************************************/

	// scale of cylinder shape 2 for bee block
	scaleXYZ = glm::vec3(2.0f, 2.5f, 2.0f); 

	// rotation of cylinder shape 2 for bee block
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 2 for bee block 
	positionXYZ = glm::vec3(7.0f, 0.0f, 14.0f); 

	// transformations of cylinder shape 2 for bee block
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	/**********************************************
	* SetShaderColor was removed as a texture
	* has been implemented for the shape
	*
	* As Cylinder Shape 2 is the base of the bee
	* block, the custom texture Bee.jpg, which 
	* consists of a color matched yellow, has been
	* loaded and set for implementation on 
	* Cylinder Shape 2
	**********************************************/
	SetShaderTexture("bee");
	SetTextureUVScale(1.0, 1.0);

	// draw cylinder 2 for bee block
	m_basicMeshes->DrawCylinderMesh(); 

	/*******************************************/
	/*          CYLINDER SHAPE 3               */
	/*******************************************/

	// scale of cylinder shape 3 for bee block
	scaleXYZ = glm::vec3(1.4f, 1.4f, 1.4f); 

	// rotation of cylinder shape 3 for bee block
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 3 for bee block
	positionXYZ = glm::vec3(7.0f, 3.0f, 14.0f);

	// transformations of cylinder shape 3 for bee block
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	/**********************************************
	* SetShaderColor was removed as a texture
	* has been implemented for the shape
	*
	* Cylinder Shape 3 is the base of the sphere and
	* as such, the cylinder needs to have a color
	* matched yellow to accurately represent the
	* bee block. The custom texture Bee.jpg was 
	* loaded and set to reflect the 2D photo bee 
	* block 
	**********************************************/
	SetShaderTexture("bee");
	SetTextureUVScale(2.0, 2.0);

	// draw cylinder shape 3 for bee block
	m_basicMeshes->DrawCylinderMesh(); 

	/*******************************************/
	/*          CYLINDER SHAPE 4              */
	/*******************************************/

	// scale of cylinder shape for bee block
	scaleXYZ = glm::vec3(2.0f, 0.75f, 2.0f);

	// rotation of cylinder shape for bee block
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position of cylinder shape for bee block
	positionXYZ = glm::vec3(7.0f, 3.1f, 14.0f);

	// transformations of cylinder shape for bee block
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/**********************************************
	* SetShaderColor was removed as a texture
	* has been implemented for the shape
	*
	* Cylinder Shape 4 is the "top" of Cylinder
	* Shape 1 and also needs to accurately match
	* the color of the bee block in the 2D photo. 
	* Cylinder Shape 4 also uses the custom Bee.jpg
	* texture to accurately represent the bee block
	**********************************************/
	SetShaderTexture("bee");
	SetTextureUVScale(1.0, 1.0);

	// draw cylinder shape for bee block
	m_basicMeshes->DrawCylinderMesh();

/****************************************************************
* Torus Shape Implementation  - Bee Block
* 
* The overall shape of the bee block is a cylinder which is 
* rounded at the top and bottom. As such, toruses were implemented
* to give the cylinders a rounded appearance
* 
* Torus Shape 1 is the upper torus on the cylinder for the 
* bee block, giving the cylinder a rounded edge at the top
* 
* Torus Shape 2 is the lower torus on the cylinder for the
* bee block, giving the cylinder a rounded edge at the bottom
*
* The rotation of both torus shapes is set to XrotationDegrees of
* 90.0f and a YrotationDegrees and ZrotationDegrees of 0.0f to 
* ensure that the toruses sit parallel with the plane
*
* Torus Shape 1 sits at a position of (7.0f, 3.5f, 14.0f) so that
* it is sitting at the top of Cylinder Shape 1 while Torus Shape
* 2 is at a position of (7.0f, 0.75f, 14.0f) so that it sits at 
* the base of Cylinder Shape 1. 
*
* Both toruses have a scale of (2.10f, 2.10f, 2.10f) so that they
* are roughly the same size as Cylinder Shape 1 as they are 
* intended to wrap the sharper edges of Cylinder Shape 1 to give
* it a rounded edge. 
*
* Initially both toruses were set to a yellow color with
* SetShaderColor. However, custom textures are now being 
* implemented to more accurately reprsent the bee block 
* in the 2D photo. As such, both toruses are set with 
* SetShaderTexture("bee");  as Bee.jpg is the color matched
* yellow texture created in Photoshop 
****************************************************************/

/*******************************************/
/*             TORUS SHAPE 1               */
/*******************************************/

	// scale of torus shape 1 for bee block
	scaleXYZ = glm::vec3(2.10f, 2.10f, 2.10f); 

	// rotation of torus shape 1 for bee block
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of torus shape 1 for bee block
	positionXYZ = glm::vec3(7.0f, 3.5f, 14.0f); 

	// transformations of torus shape 1 for bee block
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	/**********************************************
	* SetShaderColor was removed as a texture
	* has been implemented for the shape
	* 
	* Torus Shape 1 is the top edge of Cylinder 
	* Shape 1 which needs to accurately match the
	* bee block color. As such, Bee.jpg is set for
	* Torus Shape 1.
	**********************************************/
	SetShaderTexture("bee"); 
	SetTextureUVScale(1.0, 1.0); 

	// set shader material
	SetShaderMaterial("plastic");

	// draw torus shape 1 for bee block
	m_basicMeshes->DrawTorusMesh();

/*******************************************/
/*             TORUS SHAPE 2               */
/*******************************************/

	// scale of torus shape 2 for bee block
	scaleXYZ = glm::vec3(2.10f, 2.10f, 2.10f); 

	// rotation of torus shape 2 for bee block
	XrotationDegrees = 90.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of torus shape 2 for bee block
	positionXYZ = glm::vec3(7.0f, 0.75f, 14.0f); 

	// transformations of torus shape 2 for bee block
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	/**********************************************
	* SetShaderColor was removed as a texture
	* has been implemented for the shape
	*
	* Torus Shape 2 is the bottom edge of Cylinder
	* Shape 1 which also needs to accurately match 
	* the bee block in color. As such, Bee.jpg is
	* set for Torus Shape 2.
	**********************************************/
	SetShaderTexture("bee"); 
	SetTextureUVScale(1.0, 1.0); 

	// set shader material
	SetShaderMaterial("plastic");

	// draw torus shape 2 for bee block
	m_basicMeshes->DrawTorusMesh();

/****************************************************************
* Sphere Shape Implementation  - Bee Block
* 
* The sphere shape is used to represent the top of the bee block
* where the bee's face is present. 
*
* Sphere Shape 1's rotation is set to 0.0f on the X,Y, and Z
* rotationDegrees as the sphere is uniform and does not need
* to be rotated in a particular manner to represent the bee 
* block
*
* Sphere Shape 1's position is set to (7.0f, 4.5f, 14.0f) so that
* it sits in the same location as Cylinder Shape 1 in terms of X
* and Z axis while the Y axis is set to 4.5f so that it can sit 
* atop Cylinder Shape 1. 
*
* Sphere Shape 1 is at a scale of (1.5f, 1.5f, 1.5f) as it is
* slightly smaller than Cylinder shape 1. 
*
* The color of Sphere Shape 1 was initially set to a yellow which
* was a close match to the bee block. A custom texture is now
* being utilized for each shape in the bee block and Sphere Shape
* 1 utilizes Smile.jpg with a color matched yellow along with
* two eyes and a mouth.
****************************************************************/

/*******************************************/
/*             SPHERE SHAPE 1              */
/*******************************************/

	// scale of sphere shape 1 for bee block 
	scaleXYZ = glm::vec3(1.5f, 1.5f, 1.5f); 

	// rotation of sphere shape 1 for bee block
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of sphere shape 1 for bee block
	positionXYZ = glm::vec3(7.0f, 4.5f, 14.0f);

	// transformations of sphere shape 1 for bee block
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	/**********************************************
	* SetShaderColor was removed as a texture
	* has been implemented for the shape
	*
	* Sphere Shape 1 is the top of the bee block. 
	* As such, it must match in color. However, 
	* the sphere also has a bee face on it. The
	* Smile.jpg was created with a color match for
	* yellow so that it accurately matched both the
	* bee block and the other custom textures being
	* created and used on the bee block shapes. 
	* 
	* Additionally, two eyes and a smiler were
	* created on Smile.jpg and implemented. 
	* 
	* Smile.jpg needs an adjustment in terms of the
	* eye shape, but the location is near 
	* representative of the bee block in the 2D 
	* photo 
	**********************************************/
	SetShaderTexture("smile"); 
	SetTextureUVScale(1.0, 1.0);

	// set shader material
	SetShaderMaterial("plastic");

	// draw sphere shape 1 for bee block
	m_basicMeshes->DrawSphereMesh(); 

/****************************************************************
* Implementation of Meshes for Etch A Sketch -
*
* The Etch a Sketch consists of one thin, long black box shape
* under a thicker long red black box shape which makes up the
* body of the object. 
* 
* On top of the two box shapes there is a silver plane which is
* the screen of the Etch a Sketch. 
* 
* On either side of the bottom of the red box, there are two knobs
* which consist of short cylinders sitting atop smaller, thinner
* cylinders. 
****************************************************************/

/****************************************************************
* Box Shape Implementation  - Etch A Sketch 
* 
* Box Shape 1 is the the black base of the Etch A Sketch
* Box Shape 2 is the red portion of the Etch A Sketch 
*
* The rotation of both boxes is set to YrotationDegrees of -75.0f
* so that the boxes are rotated similarly to the Etch A Sketch in
* the 2D photo. 
* 
* Both boxes sit at a similar position of 10.0f, 0.0f, -3.0f but
* with variations on the Y Axis so that the red box is sitting
* on top of the black box. 
* 
* Box Shape 1 is set to a scale of 7.5f, 0.25f, 10.5f so that it
* is thin enough to be the base of the Etch A Sketch while Box 
* Shape 2 is set to 7.5f, 2.4f, 10.5f so that it is thick enough
* to replicate the photo. 
* 
* Both boxes had plastic textures created in Photoshop from 
* pre-existing plastic textures, black for Box Shape 1 and red
* for Box Shape 2. 
****************************************************************/

	/*******************************************/
	/*				BOX SHAPE 1                */
	/*******************************************/

	// scale of box shape 1 for etch a sketch
	scaleXYZ = glm::vec3(7.5f, 0.25f, 10.5f);

	// rotation of box shape 1 for etch a sketch
	XrotationDegrees = 0.0f; 
	YrotationDegrees = -75.0f; 
	ZrotationDegrees = 0.0f; 

	// position of box shape 1 for etch a sketch
	positionXYZ = glm::vec3(10.0f, 0.0f, -3.0f);

	// transformations of box shape 1 for etch a sketch
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	SetShaderTexture("etch"); 
	SetTextureUVScale(1.0, 1.0); 

	SetShaderMaterial("plastic"); 

	// draw box shape 1 for etch a sketch
	m_basicMeshes->DrawBoxMesh(); 

	/*******************************************/
	/*				BOX SHAPE 2                */
	/*******************************************/

	// scale of box shape 1 for etch a sketch
	scaleXYZ = glm::vec3(7.5f, 2.4f, 10.5f);

	// rotation of box shape 1 for etch a sketch
	XrotationDegrees = 0.0f;
	YrotationDegrees = -75.0f;
	ZrotationDegrees = 0.0f;

	// position of box shape 1 for etch a sketch
	positionXYZ = glm::vec3(10.0f, 1.2f, -3.0f);

	// transformations of box shape 1 for etch a sketch
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("sketch"); 
	SetTextureUVScale(1.0, 1.0); 

	SetShaderMaterial("plastic"); 

	// draw box shape 1 for etch a sketch
	m_basicMeshes->DrawBoxMesh();

/****************************************************************
* Plane Shape Implementation  - Etch A Sketch
*
* Plane Shape 1 is the screen
* Plane Shape 2 is the lettering 
*
* The rotation of both planes are set to -75.0f on YrotationDegrees
* so that they sit atop Box Shape 2 correctly. 
* 
* The positions are similar to Box Shape 1 and Box Shape 2 but
* differ in their position on the Y Axis so that they sit atop
* Box Shape 1 and 2. 
*
* The scale of Plane Shape 1 is smaller than that of Box Shape 2
* as Plane Shape 1 represents the screen of the Etch A Sketch. 
* 
* The scale of Plane Shape 2 is slightly smaller than that of 
* Box Shape 2 as well, but slightly larger than Plane Shape 1
* so that the lettering for the Etch A Sketch are visible. 
* 
* Plane Shape 1 has a metallic texture with glass material applied
* in order to accurately represent the reflective nature of the
* Etch A Sketch screen. 
* Plane Shape 2 has a red, plastic texture with lettering. 
****************************************************************/

	/*******************************************/
	/*				PLANE SHAPE 1              */
	/*******************************************/

	// scale of plane shape 1 for etch a sketch
	scaleXYZ = glm::vec3(2.5f, 1.0f, 4.0f);

	// rotation of plane shape 1 for etch a sketch
	XrotationDegrees = 0.0f;
	YrotationDegrees = -75.0f;
	ZrotationDegrees = 0.0f;

	// position of plane shape 1 for etch a sketch
	positionXYZ = glm::vec3(9.75f, 2.55f, -3.5f);

	// transformations of plane shape 1 for etch a sketch
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("screen"); 
	SetTextureUVScale(1.0, 1.0); 

	SetShaderMaterial("glass"); 

	// draw plane shape 1 for etch a sketch
	m_basicMeshes->DrawPlaneMesh();

	/*******************************************/
	/*				PLANE SHAPE 2              */
	/*******************************************/

	// scale of plane shape 2 for etch a sketch
	scaleXYZ = glm::vec3(3.0f, 1.0f, 5.0f);

	// rotation of plane shape 2 for etch a sketch
	XrotationDegrees = 0.0f;
	YrotationDegrees = -75.0f;
	ZrotationDegrees = 0.0f;

	// position of plane shape 2 for etch a sketch
	positionXYZ = glm::vec3(10.0f, 2.51f, -2.5f);

	// transformations of plane shape 2 for etch a sketch
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("sketchTop");
	SetTextureUVScale(1.0, 1.0);

	SetShaderMaterial("plastic");

	// draw plane shape 2 for etch a sketch
	m_basicMeshes->DrawPlaneMesh();

/****************************************************************
* Cylinder Shape Implementation  - Etch A Sketch
*
* Cylinders make up the knobs of the Etch a Sketch 
*
* The rotation of each is set to 0.0f as the knobs are cylinders
* that are uniform in shape and size. 
* 
* The knobs' positions are on the lower portion of either side of
* the Etch A Sketch. 
* 
* The scale of each is 0.9f, 0.5f, 0.9f as the knobs are small 
* and uniform in size, aside from being wider than they are tall.
* 
* A white, plastic material has been implemented for the cylinders
* representing the Etch a Sketch knobs. 
****************************************************************/

	/*******************************************/
	/*			CYLINDER SHAPE 1               */
	/*******************************************/

	// scale of cylinder shape 1 for knob
	scaleXYZ = glm::vec3(0.9f, 0.5f, 0.9f);

	// rotation of cylinder shape 1 for knob
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// position of cylinder shape 1 for knob 
	positionXYZ = glm::vec3(15.0f, 2.55f, -1.3f); 

	// transformations of cylinder shape 1 for knob
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ); 

	// TEMP FIXME
	SetShaderColor(1, 1, 1, 1); 

	// draw cylinder shape 1
	m_basicMeshes->DrawCylinderMesh();

	/*******************************************/
	/*			CYLINDER SHAPE 2               */
	/*******************************************/

	// scale of cylinder shape 2 for knob
	scaleXYZ = glm::vec3(0.9f, 0.5f, 0.9f);

	// rotation of cylinder shape 2 for knob
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// position of cylinder shape 1 for knob 
	positionXYZ = glm::vec3(6.5f, 2.55f, 1.0f);

	// transformations of cylinder shape 2 for knob
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// TEMP FIXME
	SetShaderColor(1, 1, 1, 1);

	// draw cylinder shape 2
	m_basicMeshes->DrawCylinderMesh();

}
